import { useEffect, useRef, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import Barcode from 'react-barcode';
import {
  Copy,
  Download,
  Link2,
  Plus,
  Trash2,
  User,
  Building2,
  Briefcase,
  Hash,
  Calendar,
  Image as ImageIcon,
  CheckCircle2,
  Loader2,
  ExternalLink,
  IdCard,
  Search,
  Sparkles,
  ShieldCheck,
  Globe,
  Printer,
  FileCheck2,
  AlertCircle,
  Eye,
  RefreshCw,
  Edit2
} from 'lucide-react';
import type { Certificate } from '../types/certificate';

const defaultForm = {
  full_name: '',
  full_name_ar: '',
  national_id: '',
  nationality: 'باكستان',
  gender: 'ذكر',
  profession: 'عامل مطبخ',
  workplace: 'شركة شباب الخليج المميز',
  certificate_number: '',
  amanah: 'أمانة المنطقة الشرقية',
  baladiyah: 'بلدية شرق الدمام',
  issue_date_gregorian: '2026/02/09',
  issue_date_hijri: '1447/08/21',
  expiry_date_gregorian: '2027/01/29',
  expiry_date_hijri: '1448/08/21',
  program_name: 'منشآت الغذاء',
  program_expiry_date: '1449/07/18',
  license_number: '41062972936',
  facility_number: '7016681426',
  status: 'سارية',
};

export default function AdminPage() {
  const [form, setForm] = useState(defaultForm);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>('/assets/photo.png');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [listLoading, setListLoading] = useState(true);
  const [created, setCreated] = useState<Certificate | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchCertificates = async () => {
    try {
      setListLoading(true);
      const res = await fetch('/api/certificates');
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل في تحميل الشهادات');
      setCertificates(Array.isArray(data) ? data : []);
    } catch (err: any) {
      console.error(err);
    } finally {
      setListLoading(false);
    }
  };

  useEffect(() => {
    fetchCertificates();
  }, []);

  const handleFillDemoData = () => {
    const randomNum = Math.floor(100000000000 + Math.random() * 900000000000);
    const randomLic = Math.floor(10000000000 + Math.random() * 90000000000);
    const randomNat = Math.floor(2000000000 + Math.random() * 900000000);
    setForm({
      full_name: 'MUHAMMAD SAMI ALLAH DITTA',
      full_name_ar: 'محمد سامي الله ديتة',
      national_id: String(randomNat),
      nationality: 'باكستان',
      gender: 'ذكر',
      profession: 'عامل مطبخ',
      workplace: 'شركة شباب الخليج المميز',
      certificate_number: String(randomNum),
      amanah: 'أمانة المنطقة الشرقية',
      baladiyah: 'بلدية شرق الدمام',
      issue_date_gregorian: '2026/02/09',
      issue_date_hijri: '1447/08/21',
      expiry_date_gregorian: '2027/01/29',
      expiry_date_hijri: '1448/08/21',
      program_name: 'منشآت الغذاء',
      program_expiry_date: '1449/07/18',
      license_number: String(randomLic),
      facility_number: '7016681426',
      status: 'سارية',
    });
    setPreview('/assets/photo.png');
    setError('');
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    if (!selected.type.startsWith('image/')) {
      setError('يرجى اختيار ملف صورة صالح (JPG أو PNG)');
      return;
    }
    if (selected.size > 5 * 1024 * 1024) {
      setError('يجب ألا يتعدى حجم الصورة 5 ميجابايت');
      return;
    }
    setFile(selected);
    setError('');
    const reader = new FileReader();
    reader.onload = () => setPreview(reader.result as string);
    reader.readAsDataURL(selected);
  };

  const uploadImage = async (): Promise<string | null> => {
    if (!file) {
      // If no new file uploaded, keep preview if it's already an existing URL or asset path
      if (preview && !preview.startsWith('data:')) return preview;
      return '/assets/photo.png';
    }
    const reader = new FileReader();
    return new Promise((resolve, reject) => {
      reader.onload = async () => {
        try {
          const base64 = (reader.result as string).split(',')[1];
          const res = await fetch('/api/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              fileName: file.name,
              fileBase64: base64,
              contentType: file.type,
            }),
          });
          const data = await res.json();
          if (!res.ok) throw new Error(data.error || 'فشل في رفع الصورة');
          resolve(data.url || data.path);
        } catch (err: any) {
          reject(err);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    if (!form.full_name || !form.national_id || !form.certificate_number) {
      setError('الاسم الكامل ورقم الهوية ورقم الشهادة حقول إلزامية');
      return;
    }

    setLoading(true);
    try {
      const photoUrl = await uploadImage();
      const payload = {
        ...form,
        photo_url: photoUrl || '/assets/photo.png',
        barcode_value: form.certificate_number,
      };

      let res: Response;
      if (editingId) {
        res = await fetch('/api/certificates', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: editingId, ...payload }),
        });
      } else {
        res = await fetch('/api/certificates', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      }

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل في حفظ بيانات الشهادة');

      setCreated(data);
      setSuccessMsg(editingId ? 'تم تحديث الشهادة بنجاح!' : 'تم إصدار الشهادة وحفظها بنجاح!');
      setEditingId(null);
      setFile(null);
      fetchCertificates();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (cert: Certificate) => {
    setEditingId(cert.id);
    setForm({
      full_name: cert.full_name || '',
      full_name_ar: cert.full_name_ar || '',
      national_id: cert.national_id || '',
      nationality: cert.nationality || 'باكستان',
      gender: cert.gender || 'ذكر',
      profession: cert.profession || '',
      workplace: cert.workplace || '',
      certificate_number: cert.certificate_number || '',
      amanah: cert.amanah || 'أمانة المنطقة الشرقية',
      baladiyah: cert.baladiyah || 'بلدية شرق الدمام',
      issue_date_gregorian: cert.issue_date_gregorian || cert.issue_date || '2026/02/09',
      issue_date_hijri: cert.issue_date_hijri || '1447/08/21',
      expiry_date_gregorian: cert.expiry_date_gregorian || cert.expiry_date || '2027/01/29',
      expiry_date_hijri: cert.expiry_date_hijri || '1448/08/21',
      program_name: cert.program_name || 'منشآت الغذاء',
      program_expiry_date: cert.program_expiry_date || '1449/07/18',
      license_number: cert.license_number || '41062972936',
      facility_number: cert.facility_number || '7016681426',
      status: cert.status || 'سارية',
    });
    setPreview(cert.photo_url || '/assets/photo.png');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id: number) => {
    if (!confirm('هل أنت متأكد من حذف هذه الشهادة نهائياً؟')) return;
    try {
      const res = await fetch('/api/certificates', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (!res.ok) throw new Error('فشل في حذف الشهادة');
      fetchCertificates();
      if (created?.id === id) setCreated(null);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const publicLink = created
    ? `${typeof window !== 'undefined' ? window.location.origin : ''}/certificate/${created.id}`
    : '';

  const copyLink = () => {
    if (!publicLink) return;
    navigator.clipboard.writeText(publicLink);
    alert('تم نسخ الرابط المباشر للشهادة إلى الحافظة!');
  };

  const filteredCertificates = certificates.filter((c) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.full_name?.toLowerCase().includes(q) ||
      c.full_name_ar?.toLowerCase().includes(q) ||
      c.national_id?.includes(q) ||
      c.certificate_number?.includes(q) ||
      c.workplace?.toLowerCase().includes(q) ||
      c.profession?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="min-h-screen bg-[#f3f6f4] text-[#111]" dir="rtl" style={{ fontFamily: 'TajawalLocal, system-ui, sans-serif' }}>
      {/* Top Government Bar */}
      <div className="bg-[#0b5435] text-white text-xs px-4 py-2 border-b border-[#084229]">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-300" />
            <span>منظومة بلدي الموحدة — الإدارة المركزية للشهادات الصحية والرخص البلدية</span>
          </div>
          <div className="flex items-center gap-4 text-emerald-200">
            <span>المملكة العربية السعودية 🇸🇦</span>
            <span className="hidden sm:inline">وزارة البلديات والإسكان</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#0b5435] flex items-center justify-center text-white font-bold shadow-md">
              <img src="/assets/logo-icon.svg" alt="بلدي" className="w-6 h-6 invert" onError={(e) => { (e.currentTarget as any).style.display = 'none'; }} />
            </div>
            <div>
              <h1 className="text-xl font-bold text-[#0b5435] leading-tight">لوحة إدارة الشهادات الصحية (بلدي)</h1>
              <p className="text-xs text-slate-500">إصدار ومتابعة وإدارة وثائق الشهادات الصحية المعتمدة مع الباركود وQR</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleFillDemoData}
              className="inline-flex items-center gap-1.5 text-xs bg-emerald-50 text-[#0b5435] border border-emerald-200 hover:bg-emerald-100 font-semibold px-3 py-2 rounded-lg transition"
              title="تعبئة نموذج البيانات تلقائياً للمعاينة السريعة"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>ملء ببيانات نموذجية</span>
            </button>
            <button
              onClick={fetchCertificates}
              className="inline-flex items-center gap-1 text-xs text-slate-600 hover:text-slate-900 border border-slate-200 px-3 py-2 rounded-lg hover:bg-slate-50 transition"
              title="تحديث البيانات"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">تحديث</span>
            </button>
          </div>
        </div>
      </header>

      {/* Hero Stats */}
      <div className="max-w-7xl mx-auto px-4 pt-6 pb-2">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-500">إجمالي الشهادات</p>
              <p className="text-xl font-bold text-slate-800">{certificates.length}</p>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-100 text-green-700 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-500">شهادات سارية المفعول</p>
              <p className="text-xl font-bold text-green-700">{certificates.filter(c => c.status !== 'ملغاة').length}</p>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-500">المنشآت المسجلة</p>
              <p className="text-xl font-bold text-blue-800">
                {new Set(certificates.map(c => c.workplace)).size}
              </p>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-500">بوابة التحقق الفوري</p>
              <p className="text-xs font-bold text-amber-700">مفعلة 100%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Workspace Grid */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-12 gap-6 items-start">
          {/* Form Column */}
          <div className="lg:col-span-7">
            <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-6">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-50 text-[#0b5435] flex items-center justify-center">
                    {editingId ? <Edit2 className="w-4 h-4" /> : <Plus className="w-5 h-5" />}
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-slate-800">
                      {editingId ? `تعديل الشهادة رقم #${editingId}` : 'إصدار شهادة صحية جديدة'}
                    </h2>
                    <p className="text-xs text-slate-500">بيانات الشهادة المطابقة للبوابة الرسمية لبلدي</p>
                  </div>
                </div>

                {editingId && (
                  <button
                    type="button"
                    onClick={() => { setEditingId(null); setForm(defaultForm); setPreview('/assets/photo.png'); }}
                    className="text-xs text-slate-500 hover:text-slate-800 underline"
                  >
                    إلغاء التعديل
                  </button>
                )}
              </div>

              {/* Photo & Basic Info */}
              <div className="flex flex-col sm:flex-row gap-5 items-start">
                {/* Photo uploader */}
                <div className="flex flex-col items-center gap-2 w-full sm:w-auto">
                  <label className="text-xs font-semibold text-slate-700 flex items-center gap-1">
                    <ImageIcon className="w-3.5 h-3.5 text-emerald-600" /> الصورة الشخصية
                  </label>
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="relative cursor-pointer w-28 h-28 rounded-xl border-2 border-dashed border-emerald-300 hover:border-emerald-600 bg-emerald-50/40 flex flex-col items-center justify-center overflow-hidden transition group"
                  >
                    {preview ? (
                      <img src={preview} alt="معاينة" className="w-full h-full object-cover" />
                    ) : (
                      <User className="w-10 h-10 text-emerald-400" />
                    )}
                    <div className="absolute inset-0 bg-black/40 text-white text-[10px] flex items-center justify-center opacity-0 group-hover:opacity-100 transition text-center p-1 font-semibold">
                      تغيير الصورة
                    </div>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileChange}
                  />
                  <span className="text-[10px] text-slate-400">JPG أو PNG حتى 5MB</span>
                </div>

                {/* Main Identity */}
                <div className="flex-1 w-full space-y-4">
                  <div className="grid sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 flex items-center gap-1 mb-1">
                        <User className="w-3.5 h-3.5 text-slate-500" /> الاسم الكامل (إنجليزي/لاتيني) <span className="text-red-500">*</span>
                      </label>
                      <input
                        required
                        value={form.full_name}
                        onChange={(e) => setForm({ ...form, full_name: e.target.value })}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 uppercase font-medium"
                        placeholder="MUHAMMAD SAMI ALLAH DITTA"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-700 flex items-center gap-1 mb-1">
                        <User className="w-3.5 h-3.5 text-slate-500" /> الاسم الكامل (عربي)
                      </label>
                      <input
                        value={form.full_name_ar}
                        onChange={(e) => setForm({ ...form, full_name_ar: e.target.value })}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                        placeholder="محمد سامي الله ديتة"
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 flex items-center gap-1 mb-1">
                        <IdCard className="w-3.5 h-3.5 text-slate-500" /> رقم الهوية / الإقامة <span className="text-red-500">*</span>
                      </label>
                      <input
                        required
                        value={form.national_id}
                        onChange={(e) => setForm({ ...form, national_id: e.target.value })}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 font-mono"
                        placeholder="2517075228"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-700 mb-1 block">الجنسية</label>
                      <input
                        value={form.nationality}
                        onChange={(e) => setForm({ ...form, nationality: e.target.value })}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                        placeholder="باكستان"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-700 mb-1 block">الجنس</label>
                      <select
                        value={form.gender}
                        onChange={(e) => setForm({ ...form, gender: e.target.value })}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                      >
                        <option value="ذكر">ذكر</option>
                        <option value="أنثى">أنثى</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Certificate & Municipality */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-3">
                <p className="text-xs font-bold text-slate-700 flex items-center gap-1.5 border-b border-slate-200 pb-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#0b5435]" /> بيانات الأمانة والبلدية ورقم الشهادة
                </p>

                <div className="grid sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-1 block">الأمانة</label>
                    <input
                      value={form.amanah}
                      onChange={(e) => setForm({ ...form, amanah: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                      placeholder="أمانة المنطقة الشرقية"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-1 block">البلدية</label>
                    <input
                      value={form.baladiyah}
                      onChange={(e) => setForm({ ...form, baladiyah: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                      placeholder="بلدية شرق الدمام"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 flex items-center gap-1 mb-1">
                      <Hash className="w-3.5 h-3.5 text-slate-500" /> رقم الشهادة الصحية <span className="text-red-500">*</span>
                    </label>
                    <input
                      required
                      value={form.certificate_number}
                      onChange={(e) => setForm({ ...form, certificate_number: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white font-mono focus:border-emerald-500"
                      placeholder="470822641868"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-slate-700 flex items-center gap-1 mb-1">
                      <Briefcase className="w-3.5 h-3.5 text-slate-500" /> المهنة
                    </label>
                    <input
                      value={form.profession}
                      onChange={(e) => setForm({ ...form, profession: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                      placeholder="عامل مطبخ"
                    />
                  </div>
                </div>
              </div>

              {/* Dates */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-3">
                <p className="text-xs font-bold text-slate-700 flex items-center gap-1.5 border-b border-slate-200 pb-1.5">
                  <Calendar className="w-4 h-4 text-[#0b5435]" /> تواريخ الإصدار والانتهاء (هجري وميلادي)
                </p>

                <div className="grid sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-1 block">تاريخ الإصدار (هجري)</label>
                    <input
                      value={form.issue_date_hijri}
                      onChange={(e) => setForm({ ...form, issue_date_hijri: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                      placeholder="1447/08/21"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-1 block">تاريخ الإصدار (ميلادي)</label>
                    <input
                      value={form.issue_date_gregorian}
                      onChange={(e) => setForm({ ...form, issue_date_gregorian: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                      placeholder="2026/02/09"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-1 block">تاريخ النهاية (هجري)</label>
                    <input
                      value={form.expiry_date_hijri}
                      onChange={(e) => setForm({ ...form, expiry_date_hijri: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                      placeholder="1448/08/21"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-1 block">تاريخ النهاية (ميلادي)</label>
                    <input
                      value={form.expiry_date_gregorian}
                      onChange={(e) => setForm({ ...form, expiry_date_gregorian: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                      placeholder="2027/01/29"
                    />
                  </div>
                </div>
              </div>

              {/* Training Program & Workplace */}
              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 mb-1 block">نوع البرنامج التثقيفي</label>
                  <input
                    value={form.program_name}
                    onChange={(e) => setForm({ ...form, program_name: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    placeholder="منشآت الغذاء"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 mb-1 block">تاريخ إنتهاء البرنامج التثقيفي</label>
                  <input
                    value={form.program_expiry_date}
                    onChange={(e) => setForm({ ...form, program_expiry_date: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    placeholder="1449/07/18"
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 mb-1 block">إسم المنشأة</label>
                  <input
                    value={form.workplace}
                    onChange={(e) => setForm({ ...form, workplace: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    placeholder="شركة شباب الخليج المميز"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 mb-1 block">رقم الرخصة</label>
                  <input
                    value={form.license_number}
                    onChange={(e) => setForm({ ...form, license_number: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                    placeholder="41062972936"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 mb-1 block">رقم المنشأة</label>
                  <input
                    value={form.facility_number}
                    onChange={(e) => setForm({ ...form, facility_number: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                    placeholder="7016681426"
                  />
                </div>
              </div>

              {error && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-red-50 text-red-700 text-xs border border-red-200">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {successMsg && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-50 text-[#0b5435] text-xs border border-emerald-200">
                  <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                  <span>{successMsg}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-[#0b5435] hover:bg-[#084229] text-white font-bold py-3.5 rounded-xl shadow-md transition flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
                <span>{editingId ? 'حفظ التعديلات' : 'اعتماد وإصدار الشهادة الصحية'}</span>
              </button>
            </form>
          </div>

          {/* Quick Preview & QR Column */}
          <div className="lg:col-span-5 space-y-6">
            {created ? (
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-5">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <span className="text-xs font-bold text-emerald-700 flex items-center gap-1.5 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                    <CheckCircle2 className="w-3.5 h-3.5" /> الشهادة جاهزة ومعتمدة
                  </span>
                  <span className="text-xs text-slate-400 font-mono">ID: #{created.id}</span>
                </div>

                <div className="flex items-center gap-3">
                  <img
                    src={created.photo_url || '/assets/photo.png'}
                    alt={created.full_name}
                    className="w-16 h-16 rounded-xl object-cover border-2 border-emerald-500 shadow-sm"
                  />
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{created.full_name}</h3>
                    <p className="text-xs text-slate-500 font-mono">رقم الشهادة: {created.certificate_number}</p>
                    <p className="text-xs text-emerald-700 font-medium">{created.profession} — {created.workplace}</p>
                  </div>
                </div>

                {/* Direct Links */}
                <div className="space-y-2">
                  <label className="text-xs font-medium text-slate-700 flex items-center justify-between">
                    <span className="flex items-center gap-1"><Link2 className="w-3.5 h-3.5 text-slate-400" /> رابط التحقق المباشر</span>
                    <button onClick={copyLink} className="text-emerald-700 text-[11px] font-semibold hover:underline flex items-center gap-1">
                      <Copy className="w-3 h-3" /> نسخ
                    </button>
                  </label>
                  <div className="flex gap-1.5">
                    <input
                      readOnly
                      value={publicLink}
                      className="flex-1 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-mono text-slate-700"
                    />
                  </div>
                </div>

                {/* QR Code and Barcode */}
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-col items-center justify-center text-center">
                    <p className="text-[11px] text-slate-500 font-medium mb-1.5">رمز التحقق QR</p>
                    <div className="bg-white p-2 rounded-lg border border-slate-100 shadow-xs">
                      <QRCodeSVG value={publicLink} size={110} />
                    </div>
                  </div>
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-col items-center justify-center text-center">
                    <p className="text-[11px] text-slate-500 font-medium mb-1.5">الباركود الرسمي</p>
                    <div className="bg-white p-1 rounded-lg border border-slate-100 shadow-xs max-w-full overflow-hidden">
                      <Barcode value={created.barcode_value || created.certificate_number} width={1.2} height={48} displayValue fontSize={10} />
                    </div>
                  </div>
                </div>

                {/* Quick Navigation Buttons */}
                <div className="grid sm:grid-cols-2 gap-2 pt-2">
                  <a
                    href={`/certificate/${created.id}?view=balady`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-center gap-1.5 bg-[#0b5435] hover:bg-[#084229] text-white text-xs font-bold py-2.5 px-3 rounded-lg transition text-center shadow-xs"
                  >
                    <ExternalLink className="w-3.5 h-3.5" /> بوابة بلدي (الموقع الرسمي)
                  </a>
                  <a
                    href={`/certificate/${created.id}?view=pdf`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold py-2.5 px-3 rounded-lg transition text-center shadow-xs"
                  >
                    <Printer className="w-3.5 h-3.5" /> وثيقة الشهادة الرسمية (PDF)
                  </a>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-2xl shadow-sm border-2 border-dashed border-slate-200 p-8 flex flex-col items-center justify-center text-center text-slate-400 min-h-[320px]">
                <div className="w-14 h-14 rounded-full bg-slate-50 flex items-center justify-center mb-3">
                  <Download className="w-6 h-6 text-slate-400" />
                </div>
                <h3 className="text-sm font-bold text-slate-700 mb-1">معاينة بطاقة الشهادة</h3>
                <p className="text-xs text-slate-500 max-w-xs">
                  عند إضافة شهادة جديدة أو تعديلها ستظهر الروابط المباشرة والباركود ورمز QR هنا للتحميل والطباعة.
                </p>
              </div>
            )}

            {/* Quick Balady Info Card */}
            <div className="bg-gradient-to-br from-[#0b5435] to-[#063320] text-white rounded-2xl p-5 shadow-sm space-y-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-300" />
                <h4 className="font-bold text-sm">مميزات نظام الشهادات الموحد</h4>
              </div>
              <ul className="text-xs text-emerald-100 space-y-1.5 list-disc list-inside">
                <li>متوافق 100% مع البوابة الرقمية المعتمدة لوزارة البلديات والإسكان.</li>
                <li>توليد رموز الباركود وQR المشفرة والمربوطة بالرابط المباشر.</li>
                <li>إمكانية عرض النسخة التفاعلية للهواتف الذكية أو وثيقة الطباعة A4.</li>
                <li>تخزين سحابي فوري ومستمر لجميع البيانات والصور الشخصية.</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Saved Certificates Table */}
        <div className="mt-8 bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-800">قائمة الشهادات الصادرة</h2>
              <p className="text-xs text-slate-500">سجل بجميع الشهادات المحفوظة وإمكانية البحث والتحقق والطباعة</p>
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="بحث بالاسم، الهوية، رقم الشهادة..."
                className="w-full pl-3 pr-9 py-2 text-xs rounded-lg border border-slate-300 bg-slate-50 focus:bg-white focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          {listLoading ? (
            <div className="flex flex-col items-center justify-center py-14">
              <Loader2 className="w-8 h-8 animate-spin text-[#0b5435] mb-2" />
              <p className="text-xs text-slate-500">جاري تحميل الشهادات من قاعدة البيانات...</p>
            </div>
          ) : filteredCertificates.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-sm">
              لا توجد شهادات مطابقة للبحث. انقر على &quot;ملء ببيانات نموذجية&quot; ثم &quot;اعتماد وإصدار الشهادة&quot; للبدء!
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-right">
                <thead className="bg-slate-50 text-slate-700 border-b border-slate-200">
                  <tr>
                    <th className="px-3 py-3 font-semibold rounded-r-lg">المستفيد</th>
                    <th className="px-3 py-3 font-semibold">رقم الهوية</th>
                    <th className="px-3 py-3 font-semibold">رقم الشهادة</th>
                    <th className="px-3 py-3 font-semibold">الأمانة / البلدية</th>
                    <th className="px-3 py-3 font-semibold">المهنة / المنشأة</th>
                    <th className="px-3 py-3 font-semibold">فترة الصلاحية</th>
                    <th className="px-3 py-3 font-semibold">الحالة</th>
                    <th className="px-3 py-3 font-semibold rounded-l-lg text-center">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredCertificates.map((cert) => (
                    <tr key={cert.id} className="hover:bg-slate-50/80 transition">
                      <td className="px-3 py-3 font-medium text-slate-900">
                        <div className="flex items-center gap-2">
                          <img
                            src={cert.photo_url || '/assets/photo.png'}
                            alt={cert.full_name}
                            className="w-8 h-8 rounded-lg object-cover border border-slate-200"
                            onError={(e) => { (e.currentTarget as any).src = '/assets/photo.png'; }}
                          />
                          <div>
                            <p className="font-bold text-slate-900">{cert.full_name}</p>
                            {cert.full_name_ar && <p className="text-[10px] text-slate-500">{cert.full_name_ar}</p>}
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-3 font-mono text-slate-600">{cert.national_id}</td>
                      <td className="px-3 py-3 font-mono text-emerald-800 font-bold">{cert.certificate_number}</td>
                      <td className="px-3 py-3 text-slate-600">
                        <p>{cert.amanah || '-'}</p>
                        <p className="text-[10px] text-slate-400">{cert.baladiyah || '-'}</p>
                      </td>
                      <td className="px-3 py-3 text-slate-600">
                        <p className="font-semibold text-slate-800">{cert.profession || '-'}</p>
                        <p className="text-[10px] text-slate-400">{cert.workplace || '-'}</p>
                      </td>
                      <td className="px-3 py-3 text-slate-500 whitespace-nowrap">
                        <p>{cert.issue_date_gregorian || cert.issue_date || '-'} إلى</p>
                        <p className="font-semibold text-slate-800">{cert.expiry_date_gregorian || cert.expiry_date || '-'}</p>
                      </td>
                      <td className="px-3 py-3">
                        <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-green-100 text-green-800">
                          {cert.status || 'سارية'}
                        </span>
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex items-center justify-center gap-1.5">
                          <a
                            href={`/certificate/${cert.id}?view=balady`}
                            target="_blank"
                            rel="noreferrer"
                            className="p-1.5 rounded-md text-emerald-700 hover:bg-emerald-50 transition"
                            title="عرض بوابة بلدي الرسمية"
                          >
                            <Eye className="w-4 h-4" />
                          </a>
                          <a
                            href={`/certificate/${cert.id}?view=pdf`}
                            target="_blank"
                            rel="noreferrer"
                            className="p-1.5 rounded-md text-blue-700 hover:bg-blue-50 transition"
                            title="عرض وثيقة الشهادة الرسمية PDF"
                          >
                            <Printer className="w-4 h-4" />
                          </a>
                          <button
                            onClick={() => handleEdit(cert)}
                            className="p-1.5 rounded-md text-amber-700 hover:bg-amber-50 transition"
                            title="تعديل"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(cert.id)}
                            className="p-1.5 rounded-md text-red-600 hover:bg-red-50 transition"
                            title="حذف"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
