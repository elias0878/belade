import React, { useEffect, useRef, useState } from 'react';
import { useParams, useSearchParams, Link } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import {
  Loader2,
  AlertCircle,
  Printer,
  LayoutDashboard,
  Smartphone,
  FileText,
  Share2,
  CheckCircle,
  ExternalLink,
} from 'lucide-react';
import type { Certificate } from '../types/certificate';

export default function CertificatePage() {
  const { id } = useParams<{ id: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const currentView = searchParams.get('view') === 'pdf' ? 'pdf' : 'balady';

  const [cert, setCert] = useState<Certificate | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);
  const [baladyHtml, setBaladyHtml] = useState<string>('');
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Load certificate data
  useEffect(() => {
    const fetchCert = async () => {
      try {
        setLoading(true);
        const queryId = id || searchParams.get('uuid') || searchParams.get('id') || '1';
        const res = await fetch(`/api/certificates?id=${encodeURIComponent(queryId)}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'لم يتم العثور على الشهادة المطلوبة');
        setCert(data);
      } catch (err: any) {
        setError(err.message || 'خطأ في الاتصال بالخادم');
      } finally {
        setLoading(false);
      }
    };
    fetchCert();
  }, [id, searchParams]);

  // When cert data is ready, fetch balady-source.html and inject certificate values
  useEffect(() => {
    if (!cert) return;

    const prepareBaladyHtml = async () => {
      try {
        const res = await fetch('/templates/balady-source.html');
        let html = await res.text();

        // Replace certificate fields with dynamic values
        html = html.replace('MUHAMMAD SAMI ALLAH DITTA', cert.full_name || 'MUHAMMAD SAMI ALLAH DITTA');
        html = html.replace('2517075228', cert.national_id || '2517075228');
        html = html.replace('أمانة المنطقة الشرقية', cert.amanah || 'أمانة المنطقة الشرقية');
        html = html.replace('بلدية شرق الدمام', cert.baladiyah || 'بلدية شرق الدمام');
        html = html.replace('ذكر', cert.gender || 'ذكر');
        html = html.replace('باكستان', cert.nationality || 'باكستان');
        html = html.replace('470822641868', cert.certificate_number || '470822641868');
        html = html.replace('عامل مطبخ', cert.profession || 'عامل مطبخ');
        html = html.replace('2026/02/09', cert.issue_date_gregorian || cert.issue_date || '2026/02/09');
        html = html.replace('1447/08/21', cert.issue_date_hijri || '1447/08/21');
        html = html.replace('2027/01/29', cert.expiry_date_gregorian || cert.expiry_date || '2027/01/29');
        html = html.replace('1448/08/21', cert.expiry_date_hijri || '1448/08/21');
        html = html.replace('1449/07/18', cert.program_expiry_date || '1449/07/18');
        html = html.replace('منشآت الغذاء', cert.program_name || 'منشآت الغذاء');
        html = html.replace('شركة شباب الخليج المميز', cert.workplace || 'شركة شباب الخليج المميز');
        html = html.replace('41062972936', cert.license_number || '41062972936');
        html = html.replace('7016681426', cert.facility_number || '7016681426');

        // Replace beneficiary photo
        const photoSrc = cert.photo_url || '/assets/photo.png';
        const photoRegex = /<img width="200" height="200" class="m-3" style="margin:20px" src="[^"]*"/;
        if (photoRegex.test(html)) {
          html = html.replace(
            photoRegex,
            `<img width="200" height="200" class="m-3" style="margin:20px;object-fit:cover;border-radius:12px;border:3px solid #07706d;box-shadow:0 6px 18px rgba(0,0,0,0.12);" src="${photoSrc}"`
          );
        }

        // Inject action button in the card to switch to the official PDF Certificate
        const injectPoint = '<div class="row">\n                        <div class="col-md-12 center">';
        const customAction = `
          <div class="row">
            <div class="col-md-12 text-center" style="margin: 15px 0 25px 0;">
              <button id="openPdfDocumentBtn" type="button" class="btn btn-success" style="background:#07706d;border:none;padding:12px 28px;border-radius:10px;font-weight:bold;font-size:15px;box-shadow:0 4px 14px rgba(7,112,109,0.3);cursor:pointer;color:#ffffff;display:inline-flex;align-items:center;gap:8px;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                عرض وثيقة الشهادة الرسمية للطباعة (PDF المعتمد)
              </button>
            </div>
          </div>
        `;
        html = html.replace(injectPoint, customAction + '\n' + injectPoint);

        // Inject bridge script to handle communication with parent window
        const bridgeScript = `
          <script>
            document.addEventListener('DOMContentLoaded', function() {
              var btn = document.getElementById('openPdfDocumentBtn');
              if (btn) {
                btn.addEventListener('click', function(e) {
                  e.preventDefault();
                  window.parent.postMessage({ type: 'SWITCH_TO_PDF' }, '*');
                });
              }
            });
          </script>
        `;
        html = html.replace('</body>', bridgeScript + '</body>');

        setBaladyHtml(html);
      } catch (err) {
        console.error('Failed to prepare balady HTML:', err);
      }
    };

    prepareBaladyHtml();
  }, [cert]);

  // Listen for message from iframe to switch to PDF
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'SWITCH_TO_PDF') {
        setSearchParams({ view: 'pdf' });
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [setSearchParams]);

  const publicLink = typeof window !== 'undefined' ? window.location.href : '';

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handlePrint = () => {
    if (currentView !== 'pdf') {
      setSearchParams({ view: 'pdf' });
      setTimeout(() => {
        window.print();
      }, 500);
    } else {
      window.print();
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f3f6f4] flex flex-col items-center justify-center gap-3" dir="rtl">
        <Loader2 className="w-10 h-10 animate-spin text-[#075030]" />
        <p className="text-sm font-medium text-slate-600">جاري التحقق واسترجاع رخصة الشهادة الصحية من منصة بلدي...</p>
      </div>
    );
  }

  if (error || !cert) {
    return (
      <div className="min-h-screen bg-[#f3f6f4] flex items-center justify-center p-4" dir="rtl">
        <div className="bg-white rounded-2xl shadow-lg border border-slate-200 p-8 text-center max-w-md w-full space-y-4">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto" />
          <h2 className="text-xl font-bold text-slate-800">الشهادة غير موجودة</h2>
          <p className="text-sm text-slate-600">{error || 'لم يتم العثور على وثيقة الشهادة الصحية المطلوبة.'}</p>
          <div className="pt-2">
            <Link
              to="/"
              className="inline-flex items-center gap-1.5 bg-[#075030] hover:bg-[#063d25] text-white text-xs font-bold py-2.5 px-4 rounded-xl transition"
            >
              <LayoutDashboard className="w-4 h-4" /> الانتقال إلى لوحة التحكم
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#e9edf0] text-[#111] flex flex-col" dir="rtl">
      {/* Top Floating Controller Bar - Hidden on Print */}
      <header className="print:hidden bg-[#075030] text-white border-b border-[#053822] shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-2 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Link
              to="/"
              className="flex items-center gap-1.5 text-xs bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-lg transition"
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>لوحة الإدارة</span>
            </Link>
            <span className="text-emerald-300 text-xs font-bold">
              رقم الشهادة: {cert.certificate_number}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* View Mode Switcher */}
            <div className="bg-black/25 p-0.5 rounded-lg flex items-center text-xs">
              <button
                onClick={() => setSearchParams({ view: 'balady' })}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition font-medium cursor-pointer ${
                  currentView === 'balady'
                    ? 'bg-white text-[#075030] font-bold shadow-xs'
                    : 'text-emerald-100 hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" /> بوابة بلدي (services.balady.gov.sa)
              </button>
              <button
                onClick={() => setSearchParams({ view: 'pdf' })}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition font-medium cursor-pointer ${
                  currentView === 'pdf'
                    ? 'bg-white text-[#075030] font-bold shadow-xs'
                    : 'text-emerald-100 hover:text-white'
                }`}
              >
                <FileText className="w-3.5 h-3.5" /> وثيقة الشهادة الرسمية (PDF)
              </button>
            </div>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 text-xs bg-white text-[#075030] hover:bg-emerald-50 px-3.5 py-1.5 rounded-lg font-bold shadow-xs transition cursor-pointer"
              title="طباعة وتحميل كملف PDF"
            >
              <Printer className="w-3.5 h-3.5" /> طباعة PDF
            </button>

            <button
              onClick={handleShare}
              className="flex items-center gap-1.5 text-xs bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-lg transition cursor-pointer"
              title="مشاركة الرابط المباشر"
            >
              {copied ? <CheckCircle className="w-3.5 h-3.5 text-emerald-300" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم النسخ' : 'مشاركة'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main View Area */}
      <main className="flex-1 flex flex-col">
        {currentView === 'balady' ? (
          /* ================= EXACT OFFICIAL BALADY PORTAL VIEW ================= */
          <div className="flex-1 w-full bg-white flex flex-col">
            {baladyHtml ? (
              <iframe
                ref={iframeRef}
                srcDoc={baladyHtml}
                title="شهادة صحية للأنشطة التجارية - منصة بلدي"
                className="w-full flex-1 border-0 min-h-[calc(100vh-52px)]"
              />
            ) : (
              <div className="flex flex-col items-center justify-center py-20 gap-3">
                <Loader2 className="w-8 h-8 animate-spin text-[#075030]" />
                <p className="text-sm text-slate-500">جاري عرض وتطبيق القالب الرسمي لمنصة بلدي...</p>
              </div>
            )}
          </div>
        ) : (
          /* ================= EXACT 2-PAGE PRINTABLE PDF CERTIFICATE ================= */
          <CertificatePdfView cert={cert} publicLink={publicLink} />
        )}
      </main>
    </div>
  );
}

/**
 * Exact 2-page Certificate matching web/index.html & preview.pdf
 */
function CertificatePdfView({ cert, publicLink }: { cert: Certificate; publicLink: string }) {
  const stackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function scalePages() {
      if (!stackRef.current) return;
      const hosts = stackRef.current.querySelectorAll<HTMLElement>('.pdf-page-host');
      hosts.forEach((host) => {
        const canvas = host.querySelector<HTMLElement>('.pdf-canvas');
        const baseW = Number(host.dataset.baseW);
        const baseH = Number(host.dataset.baseH);
        const hostWidth = host.clientWidth;
        if (!canvas || !baseW || !baseH || !hostWidth) return;
        const scale = hostWidth / baseW;
        host.style.height = `${baseH * scale}px`;
        canvas.style.transform = `scale(${scale})`;
      });
    }

    scalePages();
    window.addEventListener('resize', scalePages);
    return () => window.removeEventListener('resize', scalePages);
  }, []);

  return (
    <div className="w-full py-8 px-4 flex flex-col items-center">
      {/* Print styles */}
      <style>{`
        .pdf-stack {
          max-width: 1012px;
          margin: 0 auto;
          display: flex;
          flex-direction: column;
          gap: 24px;
          align-items: center;
          width: 100%;
        }
        .pdf-page-host {
          position: relative;
          width: 100%;
          max-width: var(--base-w-px);
          aspect-ratio: var(--base-w) / var(--base-h);
        }
        .pdf-canvas {
          position: absolute;
          inset: 0 auto auto 0;
          width: var(--base-w-px);
          height: var(--base-h-px);
          transform-origin: top left;
          overflow: hidden;
          box-shadow: 0 10px 30px rgba(0,0,0,.15);
          background: white;
          direction: ltr;
        }
        .pdf-page1 {
          --base-w: 1012;
          --base-h: 638;
          --base-w-px: 1012px;
          --base-h-px: 638px;
          background: linear-gradient(180deg, #f7f9fa 0%, #eff3f4 100%);
        }
        .pdf-page2 {
          --base-w: 1011;
          --base-h: 639;
          --base-w-px: 1011px;
          --base-h-px: 639px;
          background: #4a8483;
          color: white;
        }
        .pdf-art {
          position: absolute;
          inset: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
        }
        .pdf-abs { position: absolute; }
        .pdf-rtl { direction: rtl; unicode-bidi: isolate; }
        .pdf-ltr { direction: ltr; unicode-bidi: isolate; }

        /* Page 1 elements */
        .pdf-p1-titlebar {
          left: 0;
          top: 17px;
          width: 524px;
          height: 105px;
          background: #0e7270;
        }
        .pdf-p1-title {
          left: 26px;
          top: 35px;
          width: 468px;
          font-size: 52px;
          line-height: 1;
          color: #fff;
          font-weight: 700;
          text-align: right;
          letter-spacing: 0;
          font-family: 'NotoKufi', sans-serif;
        }
        .pdf-p1-balady-logo { left: 792px; top: 14px; width: 100px; height: 107px; }
        .pdf-p1-ministry-logo { left: 889px; top: 14px; width: 116px; height: 107px; }
        .pdf-p1-aseer-logo { left: 676px; top: 20px; width: 160px; height: 110px; object-fit: contain; }

        .pdf-p1-photo-frame,
        .pdf-p1-qr-frame {
          border: 1.5px solid #98c96b;
          background: rgba(255,255,255,.2);
        }
        .pdf-p1-photo-frame { left: 20px; top: 135px; width: 206px; height: 202px; }
        .pdf-p1-qr-frame { left: 20px; top: 360px; width: 206px; height: 202px; }
        .pdf-p1-photo { left: 54px; top: 153px; width: 119px; height: 191px; object-fit: cover; }
        .pdf-p1-qr { left: 52px; top: 391px; width: 123px; height: 123px; object-fit: contain; background: #fff; }

        .pdf-p1-name {
          left: 352px;
          top: 162px;
          width: 642px;
          color: #157d7b;
          font-family: 'PdfLiberationSerif', 'Times New Roman', serif;
          font-size: 35px;
          line-height: 1;
          text-align: center;
          font-weight: 400;
          letter-spacing: 0;
          white-space: nowrap;
        }

        .pdf-p1-box {
          position: absolute;
          width: 355px;
          height: 45px;
          background: #fff;
          border-radius: 4px;
        }
        .pdf-p1-label {
          position: absolute;
          font-size: 19px;
          color: #111;
          line-height: 1;
          text-align: right;
          font-weight: 400;
          white-space: nowrap;
          font-family: 'NotoKufi', sans-serif;
        }
        .pdf-p1-value-num,
        .pdf-p1-value-ar {
          position: absolute;
          width: 315px;
          font-size: 23px;
          line-height: 1;
          text-align: right;
          color: #000;
          white-space: nowrap;
        }
        .pdf-p1-value-num { font-family: 'PdfArial', Arial, sans-serif; }
        .pdf-p1-value-ar { font-family: 'NotoKufi', sans-serif; }

        .pdf-p1-l1 { left: 539px; top: 226px; width: 67px; }
        .pdf-p1-r1 { left: 897px; top: 226px; width: 96px; }
        .pdf-p1-l2 { left: 551px; top: 315px; width: 58px; }
        .pdf-p1-r2 { left: 826px; top: 315px; width: 169px; }
        .pdf-p1-l3 { left: 391px; top: 401px; width: 222px; }
        .pdf-p1-r3 { left: 774px; top: 401px; width: 222px; }
        .pdf-p1-l4 { left: 372px; top: 489px; width: 241px; }
        .pdf-p1-r4 { left: 817px; top: 489px; width: 178px; }

        .pdf-b-l1 { left: 251px; top: 255px; }
        .pdf-b-r1 { left: 638px; top: 255px; }
        .pdf-b-l2 { left: 251px; top: 346px; }
        .pdf-b-r2 { left: 638px; top: 346px; }
        .pdf-b-l3 { left: 251px; top: 433px; }
        .pdf-b-r3 { left: 638px; top: 433px; }
        .pdf-b-l4 { left: 251px; top: 519px; }
        .pdf-b-r4 { left: 638px; top: 519px; }

        .pdf-v-country { left: 268px; top: 266px; }
        .pdf-v-id { left: 665px; top: 266px; }
        .pdf-v-job { left: 268px; top: 357px; }
        .pdf-v-cert { left: 665px; top: 357px; }
        .pdf-v-exp { left: 268px; top: 444px; }
        .pdf-v-issue { left: 665px; top: 444px; }
        .pdf-v-course { left: 268px; top: 531px; }
        .pdf-v-type { left: 665px; top: 531px; }

        .pdf-p1-footer-phone { left: 20px; top: 575px; width: 273px; height: 56px; }
        .pdf-p1-footer-balady { left: 297px; top: 575px; width: 234px; height: 56px; }
        .pdf-p1-footer-social { left: 535px; top: 575px; width: 240px; height: 56px; }
        .pdf-p1-footer-web { left: 779px; top: 575px; width: 207px; height: 56px; }

        /* Page 2 elements */
        .pdf-p2-title {
          left: 44px;
          top: 32px;
          font-size: 63px;
          line-height: 1;
          color: #fff;
          font-weight: 400;
          white-space: nowrap;
          font-family: 'NotoKufi', sans-serif;
        }
        .pdf-p2-palm { left: 515px; top: 0; width: 127px; height: 109px; }
        .pdf-p2-ministry-text { left: 650px; top: 12px; width: 209px; height: 106px; }
        .pdf-p2-ministry-mark { left: 858px; top: 10px; width: 144px; height: 108px; }

        .pdf-p2-star {
          position: absolute;
          width: 53px;
          height: 53px;
        }
        .pdf-p2-text {
          position: absolute;
          text-align: right;
          color: #fff;
          font-size: 34px;
          line-height: 1.42;
          font-weight: 400;
          white-space: pre-line;
          font-family: 'NotoKufi', sans-serif;
        }
        .pdf-p2-t1 { left: 560px; top: 186px; width: 300px; font-size: 34px; }
        .pdf-p2-s1 { left: 899px; top: 186px; }
        .pdf-p2-t2 { left: 54px; top: 246px; width: 800px; font-size: 34px; }
        .pdf-p2-s2 { left: 899px; top: 266px; }
        .pdf-p2-t3 { left: 56px; top: 372px; width: 804px; font-size: 34px; }
        .pdf-p2-s3 { left: 899px; top: 391px; }
        .pdf-p2-t4 { left: 530px; top: 516px; width: 330px; font-size: 34px; }
        .pdf-p2-s4 { left: 899px; top: 523px; }

        @media print {
          @page {
            size: A4 landscape;
            margin: 0;
          }
          body {
            background: #fff !important;
            padding: 0 !important;
          }
          .pdf-stack {
            max-width: none !important;
            width: 100% !important;
            gap: 0 !important;
          }
          .pdf-page-host {
            max-width: none !important;
            width: 100vw !important;
            height: 100vh !important;
            page-break-after: always !important;
            break-after: page !important;
          }
          .pdf-page-host:last-child {
            page-break-after: auto !important;
            break-after: auto !important;
          }
          .pdf-canvas {
            position: absolute !important;
            box-shadow: none !important;
            top: 0 !important;
            left: 0 !important;
          }
        }
      `}</style>

      <div ref={stackRef} className="pdf-stack">
        {/* ================= PAGE 1 ================= */}
        <section
          className="pdf-page-host"
          data-base-w="1012"
          data-base-h="638"
          style={{ '--base-w': '1012', '--base-h': '638', '--base-w-px': '1012px', '--base-h-px': '638px' } as any}
        >
          <div className="pdf-canvas pdf-page1">
            <svg className="pdf-art" viewBox="0 0 1012 638" aria-hidden="true">
              <defs>
                <linearGradient id="p1bg" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#f7f9fa" />
                  <stop offset="100%" stopColor="#eef2f3" />
                </linearGradient>
              </defs>
              <rect width="1012" height="638" fill="url(#p1bg)" />
              <g opacity="0.35">
                <path d="M420 0 L1012 0 L1012 570 C876 548 738 520 565 486 C462 466 338 442 0 420 L0 0 Z" fill="#f7f9fa" />
                <path d="M540 0 L1012 0 L1012 515 C872 496 730 471 550 433 C509 425 472 415 420 403 Z" fill="#eef2f3" />
              </g>
              <g opacity="0.18" fill="none" stroke="#c5d0d2" strokeWidth="2">
                <path d="M744 106 C807 68 867 70 916 109" />
                <path d="M703 214 C781 123 838 96 949 67" />
                <path d="M735 396 C779 285 832 226 936 170" />
                <path d="M719 318 C790 251 851 227 950 212" />
              </g>
              <path d="M36 631 H967 Q1005 631 1005 592 V563" fill="none" stroke="#1c7978" strokeWidth="2" />
            </svg>

            <div className="pdf-abs pdf-p1-titlebar"></div>
            <div className="pdf-abs pdf-p1-title pdf-rtl">الشهادة الصحية الموحدة</div>

            <img className="pdf-abs pdf-p1-aseer-logo" src="/assets/p1_aseer_only.png" alt="" />
            <img className="pdf-abs pdf-p1-balady-logo" src="/assets/p1_balady_logo.png" alt="" />
            <img className="pdf-abs pdf-p1-ministry-logo" src="/assets/p1_ministry_logo.png" alt="" />

            <div className="pdf-abs pdf-p1-photo-frame"></div>
            <div className="pdf-abs pdf-p1-qr-frame"></div>

            {/* Photo */}
            <img
              className="pdf-abs pdf-p1-photo"
              src={cert.photo_url || '/assets/photo.png'}
              alt={cert.full_name}
              onError={(e) => { (e.currentTarget as any).src = '/assets/photo.png'; }}
            />

            {/* Dynamic QR linking to live certificate verification URL */}
            <div className="pdf-abs pdf-p1-qr flex items-center justify-center bg-white p-1">
              <QRCodeSVG value={publicLink} size={115} />
            </div>

            {/* Beneficiary Name */}
            <div className="pdf-abs pdf-p1-name pdf-ltr">
              {cert.full_name || 'SHAQEEB ISTIKHAR MUHAMMAD ISTIKHAR'}
            </div>

            {/* Labels */}
            <div className="pdf-p1-label pdf-p1-l1 pdf-rtl">الجنسية</div>
            <div className="pdf-p1-label pdf-p1-r1 pdf-rtl">رقم الهوية</div>
            <div className="pdf-p1-label pdf-p1-l2 pdf-rtl">المهنة</div>
            <div className="pdf-p1-label pdf-p1-r2 pdf-rtl">رقم الشهادة الصحية</div>
            <div className="pdf-p1-label pdf-p1-l3 pdf-rtl">تاريخ نهاية الشهادة الصحية</div>
            <div className="pdf-p1-label pdf-p1-r3 pdf-rtl">تاريخ إصدار الشهادة الصحية</div>
            <div className="pdf-p1-label pdf-p1-l4 pdf-rtl">تاريخ انتهاء البرنامج التثقيفي</div>
            <div className="pdf-p1-label pdf-p1-r4 pdf-rtl">نوع البرنامج التثقيفي</div>

            {/* Boxes */}
            <div className="pdf-p1-box pdf-b-l1"></div>
            <div className="pdf-p1-box pdf-b-r1"></div>
            <div className="pdf-p1-box pdf-b-l2"></div>
            <div className="pdf-p1-box pdf-b-r2"></div>
            <div className="pdf-p1-box pdf-b-l3"></div>
            <div className="pdf-p1-box pdf-b-r3"></div>
            <div className="pdf-p1-box pdf-b-l4"></div>
            <div className="pdf-p1-box pdf-b-r4"></div>

            {/* Dynamic Values */}
            <div className="pdf-p1-value-ar pdf-v-country pdf-rtl">{cert.nationality || 'باكستان'}</div>
            <div className="pdf-p1-value-num pdf-v-id pdf-ltr">{cert.national_id}</div>
            <div className="pdf-p1-value-ar pdf-v-job pdf-rtl">{cert.profession || 'عامل تحميل وتنزيل'}</div>
            <div className="pdf-p1-value-num pdf-v-cert pdf-ltr">{cert.certificate_number}</div>
            <div className="pdf-p1-value-num pdf-v-exp pdf-ltr">
              {cert.expiry_date_hijri || cert.expiry_date || '1449/03/13'}
            </div>
            <div className="pdf-p1-value-num pdf-v-issue pdf-ltr">
              {cert.issue_date_hijri || cert.issue_date || '1448/03/13'}
            </div>
            <div className="pdf-p1-value-num pdf-v-course pdf-ltr">
              {cert.program_expiry_date || '1450/03/13'}
            </div>
            <div className="pdf-p1-value-ar pdf-v-type pdf-rtl">{cert.program_name || 'منشآت الغذاء'}</div>

            {/* Footer Logos */}
            <img className="pdf-abs pdf-p1-footer-phone" src="/assets/p1_footer_phone.png" alt="" />
            <img className="pdf-abs pdf-p1-footer-balady" src="/assets/p1_footer_balady.png" alt="" />
            <img className="pdf-abs pdf-p1-footer-social" src="/assets/p1_footer_social.png" alt="" />
            <img className="pdf-abs pdf-p1-footer-web" src="/assets/p1_footer_web.png" alt="" />
          </div>
        </section>

        {/* ================= PAGE 2 ================= */}
        <section
          className="pdf-page-host"
          data-base-w="1011"
          data-base-h="639"
          style={{ '--base-w': '1011', '--base-h': '639', '--base-w-px': '1011px', '--base-h-px': '639px' } as any}
        >
          <div className="pdf-canvas pdf-page2">
            <svg className="pdf-art" viewBox="0 0 1011 639" aria-hidden="true">
              <rect width="1011" height="639" fill="#4a8483" />
              <g opacity="0.16" fill="none" stroke="#b8cdcd" strokeWidth="2">
                <path d="M0 22 C97 125 151 236 193 497" />
                <path d="M0 309 C58 367 123 456 121 637" />
                <path d="M20 58 C69 104 156 124 235 220" />
                <path d="M19 243 C89 247 131 300 192 499" />
              </g>
            </svg>

            <div className="pdf-abs pdf-p2-title pdf-rtl">تعليمات وإرشادات</div>
            <img className="pdf-abs pdf-p2-palm" src="/assets/p2_palm_circle2.png" alt="" />
            <img className="pdf-abs pdf-p2-ministry-text" src="/assets/p2_ministry_text2.png" alt="" />
            <img className="pdf-abs pdf-p2-ministry-mark" src="/assets/p2_ministry_mark2.png" alt="" />

            <div className="pdf-p2-text pdf-p2-t1 pdf-rtl">شهادة صحية تجدد سنوياً.</div>
            <img className="pdf-p2-star pdf-p2-s1" src="/assets/p2_bullet2.png" alt="" />

            <div className="pdf-p2-text pdf-p2-t2 pdf-rtl">
              يسمح لحامل الشهادة الصحية بالعمل في منشآت الغذاء أو الصحة العامة وفق المهنة المسموح بها نظاماً.
            </div>
            <img className="pdf-p2-star pdf-p2-s2" src="/assets/p2_bullet2.png" alt="" />

            <div className="pdf-p2-text pdf-p2-t3 pdf-rtl">
              يلزم حامل هذه الشهادة بإجراء فحص طبي عند عودته من الخارج قبل البدء بممارسة العمل.
            </div>
            <img className="pdf-p2-star pdf-p2-s3" src="/assets/p2_bullet2.png" alt="" />

            <div className="pdf-p2-text pdf-p2-t4 pdf-rtl">لا تعتبر الشهادة إثبات هوية.</div>
            <img className="pdf-p2-star pdf-p2-s4" src="/assets/p2_bullet2.png" alt="" />
          </div>
        </section>
      </div>
    </div>
  );
}
