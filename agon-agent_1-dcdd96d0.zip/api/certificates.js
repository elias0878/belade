import supabase from './db-client.js';

function getPublicUrl(path) {
  if (!path) return '';
  if (path.startsWith('http://') || path.startsWith('https://')) return path;
  if (path.startsWith('data:')) return path;
  if (path.startsWith('/')) return path;
  try {
    const { data } = supabase.storage.from('certificate-photos').getPublicUrl(path);
    return data?.publicUrl || path;
  } catch {
    return path;
  }
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { id, uuid, certificate_number } = req.query;

      if (id || uuid || certificate_number) {
        let query = supabase.from('certificates').select('*');
        if (id) {
          // Can be integer id or uuid
          if (/^\d+$/.test(id)) {
            query = query.eq('id', parseInt(id, 10));
          } else {
            query = query.or(`uuid.eq.${id},certificate_number.eq.${id}`);
          }
        } else if (uuid) {
          query = query.or(`uuid.eq.${uuid},certificate_number.eq.${uuid}`);
        } else if (certificate_number) {
          query = query.eq('certificate_number', certificate_number);
        }

        const { data, error } = await query.maybeSingle();
        if (error) throw error;
        if (!data) return res.status(404).json({ error: 'الشهادة المطلوبة غير موجودة' });

        return res.status(200).json({
          ...data,
          photo_url: getPublicUrl(data.photo_url),
        });
      }

      const { data, error } = await supabase
        .from('certificates')
        .select('*')
        .order('id', { ascending: false });

      if (error) throw error;
      return res.status(200).json(
        (data || []).map((c) => ({
          ...c,
          photo_url: getPublicUrl(c.photo_url),
        }))
      );
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      const {
        full_name,
        full_name_ar,
        national_id,
        nationality,
        gender,
        profession,
        workplace,
        certificate_number,
        amanah,
        baladiyah,
        issue_date_gregorian,
        issue_date_hijri,
        expiry_date_gregorian,
        expiry_date_hijri,
        issue_date,
        expiry_date,
        program_name,
        program_expiry_date,
        license_number,
        facility_number,
        photo_url,
        barcode_value,
        uuid,
        status,
      } = body;

      if (!full_name || !national_id || !certificate_number) {
        return res.status(400).json({
          error: 'الاسم الكامل، رقم الهوية، ورقم الشهادة حقول إلزامية',
        });
      }

      const generatedUuid =
        uuid ||
        `CERT-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

      const { data, error } = await supabase
        .from('certificates')
        .insert({
          full_name,
          full_name_ar: full_name_ar || full_name,
          national_id,
          nationality: nationality || 'سعودي',
          gender: gender || 'ذكر',
          profession: profession || 'مهنة صحية',
          workplace: workplace || 'منشأة تجارية',
          certificate_number,
          amanah: amanah || 'أمانة المنطقة الشرقية',
          baladiyah: baladiyah || 'بلدية شرق الدمام',
          issue_date_gregorian: issue_date_gregorian || issue_date || '2026/02/09',
          issue_date_hijri: issue_date_hijri || '1447/08/21',
          expiry_date_gregorian: expiry_date_gregorian || expiry_date || '2027/01/29',
          expiry_date_hijri: expiry_date_hijri || '1448/08/21',
          issue_date: issue_date || issue_date_gregorian || '2026/02/09',
          expiry_date: expiry_date || expiry_date_gregorian || '2027/01/29',
          program_name: program_name || 'منشآت الغذاء',
          program_expiry_date: program_expiry_date || '1449/07/18',
          license_number: license_number || '41062972936',
          facility_number: facility_number || '7016681426',
          photo_url: photo_url || '',
          barcode_value: barcode_value || certificate_number,
          uuid: generatedUuid,
          status: status || 'سارية',
        })
        .select()
        .single();

      if (error) throw error;
      return res.status(201).json({
        ...data,
        photo_url: getPublicUrl(data.photo_url),
      });
    }

    if (req.method === 'PUT') {
      const { id, ...rest } = req.body || {};
      if (!id) return res.status(400).json({ error: 'معرّف الشهادة id مطلوب' });

      const { data, error } = await supabase
        .from('certificates')
        .update(rest)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return res.status(200).json({
        ...data,
        photo_url: getPublicUrl(data.photo_url),
      });
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'معرّف الشهادة id مطلوب للحذف' });

      const { error } = await supabase.from('certificates').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'طريقة الطلب غير مسموح بها' });
  } catch (err) {
    console.error('Certificates API error:', err);
    res.status(500).json({ error: err.message || 'خطأ داخلي في الخادم' });
  }
}
