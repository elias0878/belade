import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Barcode from 'react-barcode';
import { QRCodeSVG } from 'qrcode.react';
import { Loader2, ShieldCheck, User, Building2, Briefcase, Hash, Calendar, AlertCircle } from 'lucide-react';

interface Certificate {
  id: number;
  full_name: string;
  national_id: string;
  profession: string;
  workplace: string;
  certificate_number: string;
  issue_date: string;
  expiry_date: string;
  photo_url: string;
  barcode_value: string;
  created_at: string;
}

export default function CertificatePage() {
  const { id } = useParams<{ id: string }>();
  const [cert, setCert] = useState<Certificate | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchCert = async () => {
      try {
        const res = await fetch(`/api/certificates?id=${id}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Certificate not found');
        setCert(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchCert();
  }, [id]);

  const publicLink = typeof window !== 'undefined' ? window.location.href : '';

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center" dir="rtl">
        <Loader2 className="w-10 h-10 animate-spin text-emerald-600" />
      </div>
    );
  }

  if (error || !cert) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4" dir="rtl">
        <div className="bg-white rounded-2xl shadow-xl p-8 text-center max-w-md">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-slate-800 mb-2">الشهادة غير موجودة</h2>
          <p className="text-slate-600">{error || 'لم يتم العثور على بيانات الشهادة المطلوبة'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-slate-100 py-8 px-4" dir="rtl">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100">
          <div className="bg-gradient-to-l from-emerald-700 to-emerald-500 px-6 py-6 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-8 h-8" />
              <div>
                <h1 className="text-xl md:text-2xl font-bold">شهادة صحية معتمدة</h1>
                <p className="text-emerald-100 text-sm">Health Certificate</p>
              </div>
            </div>
            <div className="hidden sm:block text-left">
              <p className="text-xs text-emerald-100">رقم الشهادة</p>
              <p className="font-bold">{cert.certificate_number}</p>
            </div>
          </div>

          <div className="p-6 md:p-10">
            <div className="flex flex-col md:flex-row gap-6 items-start">
              <div className="flex-shrink-0 mx-auto md:mx-0">
                {cert.photo_url ? (
                  <img
                    src={cert.photo_url}
                    alt={cert.full_name}
                    className="w-36 h-36 md:w-44 md:h-44 rounded-2xl object-cover border-4 border-emerald-50 shadow-lg"
                  />
                ) : (
                  <div className="w-36 h-36 md:w-44 md:h-44 rounded-2xl bg-slate-100 border-4 border-emerald-50 flex items-center justify-center shadow-lg">
                    <User className="w-16 h-16 text-slate-300" />
                  </div>
                )}
              </div>

              <div className="flex-1 w-full space-y-4">
                <Field icon={<User className="w-4 h-4" />} label="الاسم الكامل" value={cert.full_name} />
                <Field icon={<Hash className="w-4 h-4" />} label="رقم الهوية / الإقامة" value={cert.national_id} />
                <Field icon={<Briefcase className="w-4 h-4" />} label="المهنة" value={cert.profession || '-'} />
                <Field icon={<Building2 className="w-4 h-4" />} label="جهة العمل / المنشأة" value={cert.workplace || '-'} />

                <div className="grid sm:grid-cols-2 gap-4 pt-2">
                  <Field icon={<Calendar className="w-4 h-4" />} label="تاريخ الإصدار" value={cert.issue_date || '-'} />
                  <Field icon={<Calendar className="w-4 h-4" />} label="تاريخ الانتهاء" value={cert.expiry_date || '-'} />
                </div>
              </div>
            </div>

            <div className="mt-10 pt-8 border-t border-slate-100">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
                <div className="text-center sm:text-right">
                  <p className="text-sm text-slate-500 mb-1">رمز التحقق — الباركود</p>
                  <div className="bg-white p-2 rounded-lg inline-block">
                    <Barcode value={cert.barcode_value} width={2} height={60} displayValue fontSize={13} />
                  </div>
                </div>
                <div className="text-center">
                  <p className="text-sm text-slate-500 mb-1">امسح للتحقق من الشهادة</p>
                  <QRCodeSVG value={publicLink} size={120} />
                </div>
              </div>
            </div>

            <div className="mt-8 text-center text-xs text-slate-400">
              تم إصدار هذه الشهادة إلكترونياً — {new Date(cert.created_at).toLocaleDateString('ar-SA')}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="mt-1 text-emerald-600">{icon}</div>
      <div>
        <p className="text-xs text-slate-500">{label}</p>
        <p className="text-base md:text-lg font-semibold text-slate-800">{value}</p>
      </div>
    </div>
  );
}
