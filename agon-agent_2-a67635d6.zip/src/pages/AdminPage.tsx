import { useEffect, useRef, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import Barcode from 'react-barcode';
import { Copy, Download, Link2, Plus, Trash2, User, Building2, Briefcase, Hash, Calendar, Image as ImageIcon, CheckCircle2, Loader2, ExternalLink, IdCard } from 'lucide-react';

interface Certificate {
  id: number;
  full_name: string;
  national_id: string;
  profession: string;
  workplace: string;
  certificate_number: string;
  issue_date: string;
  expiry_date: string;
  photo_url: string;
  barcode_value: string;
  created_at: string;
}

const initialForm = {
  full_name: '',
  national_id: '',
  profession: '',
  workplace: '',
  certificate_number: '',
  issue_date: '',
  expiry_date: '',
};

export default function AdminPage() {
  const [form, setForm] = useState(initialForm);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [listLoading, setListLoading] = useState(true);
  const [created, setCreated] = useState<Certificate | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchCertificates = async () => {
    try {
      setListLoading(true);
      const res = await fetch('/api/certificates');
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to fetch');
      setCertificates(Array.isArray(data) ? data : []);
    } catch (err: any) {
      console.error(err);
    } finally {
      setListLoading(false);
    }
  };

  useEffect(() => {
    fetchCertificates();
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    if (!selected.type.startsWith('image/')) {
      setError('Please select an image file');
      return;
    }
    if (selected.size > 5 * 1024 * 1024) {
      setError('Image must be smaller than 5MB');
      return;
    }
    setFile(selected);
    setError('');
    const reader = new FileReader();
    reader.onload = () => setPreview(reader.result as string);
    reader.readAsDataURL(selected);
  };

  const uploadImage = async (): Promise<string | null> => {
    if (!file) return null;
    const reader = new FileReader();
    return new Promise((resolve, reject) => {
      reader.onload = async () => {
        try {
          const base64 = (reader.result as string).split(',')[1];
          const res = await fetch('/api/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              fileName: file.name,
              fileBase64: base64,
              contentType: file.type,
            }),
          });
          const data = await res.json();
          if (!res.ok) throw new Error(data.error || 'Upload failed');
          resolve(data.path);
        } catch (err: any) {
          reject(err);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setCreated(null);

    if (!form.full_name || !form.national_id || !form.certificate_number) {
      setError('Name, national ID and certificate number are required');
      return;
    }

    setLoading(true);
    try {
      const photoPath = await uploadImage();
      const payload = { ...form, photo_url: photoPath || '' };
      const res = await fetch('/api/certificates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create certificate');
      setCreated(data);
      setForm(initialForm);
      setFile(null);
      setPreview('');
      fetchCertificates();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('هل أنت متأكد من حذف هذه الشهادة؟')) return;
    try {
      const res = await fetch('/api/certificates', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (!res.ok) throw new Error('Delete failed');
      fetchCertificates();
      if (created?.id === id) setCreated(null);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const publicLink = created ? `${window.location.origin}/certificate/${created.id}` : '';

  const copyLink = () => {
    if (!publicLink) return;
    navigator.clipboard.writeText(publicLink);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-200 py-8 px-4" dir="rtl">
      <div className="max-w-5xl mx-auto space-y-8">
        <header className="text-center space-y-2">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-800">لوحة إدارة الشهادات الصحية</h1>
          <p className="text-slate-600">أضف بيانات مستخدم جديد مع صورته الشخصية واحصل على رابط وباركود مخصص</p>
        </header>

        <div className="grid lg:grid-cols-2 gap-8 items-start">
          <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-xl p-6 md:p-8 space-y-5">
            <h2 className="text-xl font-semibold text-slate-800 flex items-center gap-2">
              <Plus className="w-5 h-5" /> إضافة شهادة جديدة
            </h2>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-sm font-medium text-slate-700 flex items-center gap-1">
                  <User className="w-4 h-4" /> الاسم الكامل <span className="text-red-500">*</span>
                </label>
                <input
                  required
                  value={form.full_name}
                  onChange={(e) => setForm({ ...form, full_name: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  placeholder="محمد أحمد عبدالله"
                />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium text-slate-700 flex items-center gap-1">
                  <IdCard className="w-4 h-4" /> رقم الهوية / الإقامة <span className="text-red-500">*</span>
                </label>
                <input
                  required
                  value={form.national_id}
                  onChange={(e) => setForm({ ...form, national_id: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  placeholder="1234567890"
                />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-sm font-medium text-slate-700 flex items-center gap-1">
                  <Briefcase className="w-4 h-4" /> المهنة
                </label>
                <input
                  value={form.profession}
                  onChange={(e) => setForm({ ...form, profession: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  placeholder="طباخ"
                />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium text-slate-700 flex items-center gap-1">
                  <Building2 className="w-4 h-4" /> جهة العمل / المنشأة
                </label>
                <input
                  value={form.workplace}
                  onChange={(e) => setForm({ ...form, workplace: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  placeholder="مطعم الأصالة"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-sm font-medium text-slate-700 flex items-center gap-1">
                <Hash className="w-4 h-4" /> رقم الشهادة <span className="text-red-500">*</span>
              </label>
              <input
                required
                value={form.certificate_number}
                onChange={(e) => setForm({ ...form, certificate_number: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                placeholder="HC-2026-0001"
              />
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-sm font-medium text-slate-700 flex items-center gap-1">
                  <Calendar className="w-4 h-4" /> تاريخ الإصدار
                </label>
                <input
                  type="date"
                  value={form.issue_date}
                  onChange={(e) => setForm({ ...form, issue_date: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium text-slate-700 flex items-center gap-1">
                  <Calendar className="w-4 h-4" /> تاريخ الانتهاء
                </label>
                <input
                  type="date"
                  value={form.expiry_date}
                  onChange={(e) => setForm({ ...form, expiry_date: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 flex items-center gap-1">
                <ImageIcon className="w-4 h-4" /> الصورة الشخصية
              </label>
              <div
                onClick={() => fileInputRef.current?.click()}
                className="cursor-pointer border-2 border-dashed border-slate-300 rounded-xl p-6 flex flex-col items-center justify-center text-center hover:border-emerald-500 hover:bg-emerald-50 transition"
              >
                {preview ? (
                  <img src={preview} alt="Preview" className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-md" />
                ) : (
                  <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mb-2">
                    <ImageIcon className="w-7 h-7 text-slate-400" />
                  </div>
                )}
                <span className="text-sm text-slate-600">
                  {preview ? 'انقر لتغيير الصورة' : 'انقر لرفع صورة شخصية'}
                </span>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileChange}
                />
              </div>
            </div>

            {error && <p className="text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg">{error}</p>}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 rounded-lg transition flex items-center justify-center gap-2 disabled:opacity-70"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
              حفظ الشهادة
            </button>
          </form>

          {created ? (
            <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8 space-y-6">
              <h2 className="text-xl font-semibold text-slate-800 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" /> تم إنشاء الشهادة
              </h2>

              <div className="flex flex-col items-center gap-4">
                {created.photo_url && (
                  <img
                    src={created.photo_url}
                    alt={created.full_name}
                    className="w-28 h-28 rounded-full object-cover border-4 border-emerald-100 shadow"
                  />
                )}
                <div className="text-center">
                  <p className="text-lg font-bold text-slate-800">{created.full_name}</p>
                  <p className="text-sm text-slate-500">{created.certificate_number}</p>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700 flex items-center gap-1">
                  <Link2 className="w-4 h-4" /> الرابط المخصص
                </label>
                <div className="flex gap-2">
                  <input
                    readOnly
                    value={publicLink}
                    className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm bg-slate-50"
                  />
                  <button
                    onClick={copyLink}
                    className="bg-slate-800 hover:bg-slate-900 text-white px-3 py-2 rounded-lg transition"
                    title="نسخ الرابط"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
                <a
                  href={publicLink}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-emerald-600 hover:text-emerald-700 text-sm"
                >
                  فتح صفحة الشهادة <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">الباركود</label>
                <div className="flex justify-center bg-white p-2 rounded-lg border border-slate-200">
                  <Barcode value={created.barcode_value} width={2} height={60} displayValue fontSize={14} />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">رمز QR</label>
                <div className="flex justify-center">
                  <QRCodeSVG value={publicLink} size={140} />
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white/70 rounded-2xl border-2 border-dashed border-slate-300 p-8 flex flex-col items-center justify-center text-center text-slate-500 min-h-[300px]">
              <Download className="w-12 h-12 mb-3 opacity-50" />
              <p>ستظهر الرابط والباركود هنا بعد الحفظ</p>
            </div>
          )}
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8">
          <h2 className="text-xl font-semibold text-slate-800 mb-4">الشهادات المحفوظة</h2>
          {listLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
            </div>
          ) : certificates.length === 0 ? (
            <p className="text-slate-500 text-center py-8">لا توجد شهادات محفوظة بعد</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 text-slate-700">
                  <tr>
                    <th className="text-right px-4 py-3 rounded-r-lg">الاسم</th>
                    <th className="text-right px-4 py-3">رقم الهوية</th>
                    <th className="text-right px-4 py-3">رقم الشهادة</th>
                    <th className="text-right px-4 py-3">التاريخ</th>
                    <th className="text-right px-4 py-3 rounded-l-lg">إجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {certificates.map((cert) => (
                    <tr key={cert.id} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="px-4 py-3 font-medium">{cert.full_name}</td>
                      <td className="px-4 py-3">{cert.national_id}</td>
                      <td className="px-4 py-3">{cert.certificate_number}</td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {cert.issue_date || '-'} / {cert.expiry_date || '-'}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <a
                            href={`/certificate/${cert.id}`}
                            target="_blank"
                            rel="noreferrer"
                            className="text-emerald-600 hover:text-emerald-700"
                            title="عرض"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </a>
                          <button
                            onClick={() => handleDelete(cert.id)}
                            className="text-red-600 hover:text-red-700"
                            title="حذف"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
