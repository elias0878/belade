import supabase from './db-client.js';

function getPublicUrl(path) {
  if (!path) return null;
  if (path.startsWith('http')) return path;
  const { data } = supabase.storage.from('certificate-photos').getPublicUrl(path);
  return data?.publicUrl || null;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { id } = req.query;
      if (id) {
        const { data, error } = await supabase
          .from('certificates')
          .select('*')
          .eq('id', id)
          .single();
        if (error) throw error;
        if (!data) return res.status(404).json({ error: 'Certificate not found' });
        return res.status(200).json({
          ...data,
          photo_url: getPublicUrl(data.photo_url),
        });
      }
      const { data, error } = await supabase
        .from('certificates')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(
        (data || []).map((c) => ({ ...c, photo_url: getPublicUrl(c.photo_url) }))
      );
    }

    if (req.method === 'POST') {
      const {
        full_name,
        national_id,
        profession,
        workplace,
        certificate_number,
        issue_date,
        expiry_date,
        photo_url,
      } = req.body;

      if (!full_name || !national_id || !certificate_number) {
        return res.status(400).json({ error: 'full_name, national_id and certificate_number are required' });
      }

      const barcode_value = certificate_number;
      const { data, error } = await supabase
        .from('certificates')
        .insert({
          full_name,
          national_id,
          profession: profession || '',
          workplace: workplace || '',
          certificate_number,
          issue_date: issue_date || '',
          expiry_date: expiry_date || '',
          photo_url: photo_url || '',
          barcode_value,
        })
        .select()
        .single();

      if (error) throw error;
      return res.status(201).json({
        ...data,
        photo_url: getPublicUrl(data.photo_url),
      });
    }

    if (req.method === 'PUT') {
      const { id, ...rest } = req.body;
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { data, error } = await supabase
        .from('certificates')
        .update(rest)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json({
        ...data,
        photo_url: getPublicUrl(data.photo_url),
      });
    }

    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('certificates').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Certificates API error:', err);
    res.status(500).json({ error: err.message || 'Internal server error' });
  }
}
