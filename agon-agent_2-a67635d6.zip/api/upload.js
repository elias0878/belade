import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { fileName, fileBase64, contentType } = req.body;
    if (!fileName || !fileBase64 || !contentType) {
      return res.status(400).json({ error: 'fileName, fileBase64 and contentType are required' });
    }

    const buffer = Buffer.from(fileBase64, 'base64');
    const uniqueName = `${Date.now()}_${Math.random().toString(36).slice(2, 10)}_${fileName}`;

    const { data, error } = await supabase.storage
      .from('certificate-photos')
      .upload(uniqueName, buffer, { contentType, upsert: false });

    if (error) throw error;

    const { data: urlData } = supabase.storage
      .from('certificate-photos')
      .getPublicUrl(data.path);

    return res.status(200).json({ path: data.path, url: urlData.publicUrl });
  } catch (err) {
    console.error('Upload API error:', err);
    res.status(500).json({ error: err.message || 'Internal server error' });
  }
}
