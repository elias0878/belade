import { createClient } from '@supabase/supabase-js';

const supabaseUrl =
  import.meta.env.VITE_SUPABASE_URL ||
  import.meta.env.NEXT_PUBLIC_SUPABASE_URL ||
  'https://eamoovwerapqifussnac.supabase.co';

const supabaseAnonKey =
  import.meta.env.VITE_SUPABASE_ANON_KEY ||
  import.meta.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  'sb_publishable_wrjQNS7Ht1fKEEQD5EcZ9w_lg6hW7c7';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
export default supabase;
