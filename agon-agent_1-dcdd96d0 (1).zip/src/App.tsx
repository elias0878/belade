import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import AdminPage from './pages/AdminPage';
import CertificatePage from './pages/CertificatePage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public root directly shows the official certificate */}
        <Route path="/" element={<Navigate to="/certificate/1" replace />} />
        {/* Admin panel is ONLY accessible directly via /admin */}
        <Route path="/admin" element={<AdminPage />} />
        {/* Certificate view */}
        <Route path="/certificate/:id" element={<CertificatePage />} />
        {/* Official Balady path */}
        <Route path="/health/issue/PrintedLicenses" element={<CertificatePage />} />
        {/* Fallback */}
        <Route path="*" element={<Navigate to="/certificate/1" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
